Name: Steven Call
Email: steven.call@wsu.edu

Description:

	This program searches wikipedia for a specific title of a page(List of rock and roll performers), 
	then goes in and looks at its content. The program then collects the names of these artists and 
	follows their attached link to find more information on each person. The program collects the year 
	the group or artist started music, the year they were born (for artists) and year they died. If 
	they are still alive or information was not available the spot will be blank. This then puts the 
	information into an xml file.

How to build/run:

	- cd into the directory and enter the command python assign1.py
	- After code is compiled open RockandRoll.xml to see xml file that is saved

Files in Archive:

assign1.py..............Main file that runs program.
README................This file explaining how to run and what the program does.
